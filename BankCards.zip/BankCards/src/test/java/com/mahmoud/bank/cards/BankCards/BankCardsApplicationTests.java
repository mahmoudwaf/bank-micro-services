package com.mahmoud.bank.cards.BankCards;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankCardsApplicationTests {

	@Test
	void contextLoads() {
	}

}
